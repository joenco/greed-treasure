package com.minotauro.base.util;

public enum EnumEditMode {
  CREATE, UPDATE, SELECT
}
